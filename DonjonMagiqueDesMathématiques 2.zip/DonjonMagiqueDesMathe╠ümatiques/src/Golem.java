class Golem{
    int degat;
    //Formule[] formule;
    int pv;
}