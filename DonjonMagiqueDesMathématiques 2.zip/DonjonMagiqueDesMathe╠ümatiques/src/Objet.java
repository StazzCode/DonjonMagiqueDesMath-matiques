class Objet{
   String nom;
  
}