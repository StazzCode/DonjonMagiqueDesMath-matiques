class Formule{
    int facteur1;
    int facteur2;
    char operateur;
    int resultat;
}