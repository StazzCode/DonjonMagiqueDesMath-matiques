class Salle{
    TypeSalle type = TypeSalle.PAS_DEF;
    boolean gauche = false;
    boolean droite = false; 
    boolean haut = false;
    boolean bas = false;
    boolean visitee = false;
    int nbmonstre = 0;
}