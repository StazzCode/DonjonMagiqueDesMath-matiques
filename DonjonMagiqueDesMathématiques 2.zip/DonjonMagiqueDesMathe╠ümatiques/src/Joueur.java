class Joueur{
    int pv = 10;
    Arme[] inventaireArme;
}