class Etage{
    Salle[][] plan = new Salle[10][10];
    int numero;
    boolean visite;
}