class Partie{
    int[] etage;
    int[] positionJoueur;
    int[] inventaire;
}