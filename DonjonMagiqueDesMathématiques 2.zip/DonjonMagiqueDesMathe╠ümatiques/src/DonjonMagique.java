import extensions.File;

import java.lang.ref.Cleaner.Cleanable;

import javax.swing.text.PlainView;

import extensions.CSVFile;

class DonjonMagique extends Program{

    final int pvGolem = 5;
    final int pvJoueur = 10;
    final int degGolem = 1;

    Arme newArme(String nom, Rarete rarete, Type type, int dmg){ //Fonction créant une arme et définissant ses paramètres: (nom, rarete, type, points de dégats)
        Arme a = new Arme();
        a.nom = nom;
        a.rarete = rarete;
        a.type = type;
        a.dmg = dmg;
        return a;
    }
    Joueur newJoueur(Arme[] inventaireArme){
        Joueur j = new Joueur();
        j.inventaireArme = inventaireArme;
        return j;
    }
    Formule newFormule(int facteur1, int facteur2, char operateur){
        Formule f = new Formule();
        f.facteur1 = facteur1;
        f.facteur2 = facteur2;
        f.operateur = operateur;
        f.resultat = calculResultatFormule(facteur1, facteur2, operateur);
        return f;
    }
    Golem newGolem(int pv, int degat/*, String operation*/){
        Golem g = new Golem();
        g.pv = pv;
        g.degat = degat;
        //g.formule = creerTabFormules(pv, operation);
        return g;
    }
    int StringToInt(String str){
        int nombre = 0;
        if(length(str) == 2){
            nombre = (((int)charAt(str,0))%48)*10 + ((int)charAt(str,1))%48;
        }else{
            nombre = ((int)charAt(str,0))%48;
        }
        return nombre;
    }
    String intToString(int nb){
        String chaine = "";
        if(nb < 10){
            chaine += ((char) nb)%48;
        }else{
            chaine += ((char) nb/10)%48;
            chaine += ((char) (nb - (nb/10)*10))%48;
        }
        return chaine;
    }
    void testStringToInt(){
        assertEquals(12,stringToInt("12"));
    }
    void testIntToString(){
        assertEquals("12",intToString(12));
    }
    Formule initialiserFormule(String operation){
        CSVFile fichier = loadCSV("../operation/"+operation+".csv");
        Formule formule = new Formule();
        String facteur1 = "";
        String facteur2 = "";
        char operateur;
        String currentLine = "";
        int aleatoire = ((int)random())*rowCount(fichier);
        currentLine = getCell(fichier,aleatoire,0);
        int indice = 0;
        while(charAt(currentLine,indice) >= '0' && charAt(currentLine,indice) <= '9' && indice < 2){
            facteur1 = facteur1 + charAt(currentLine,indice);
            indice++;
        }
        operateur = charAt(currentLine,indice);
        facteur2 = substring(currentLine,indice+1,length(currentLine));
        formule.facteur1= StringToInt(facteur1);
        formule.facteur2= StringToInt(facteur2);
        formule.operateur= operateur;
        return formule;
    }
    /*Formule[] creerTabFormules(int nbFormules, String operation){
        Formule[] tab = new Formule[nbFormules];
        for (int i = 0; i <nbFormules; i=i+1){
            tab[i] = initialiserFormule(operation);
        }
        return tab;
    }*/
    Etage newEtage(int numero){
        Etage etage = new Etage();
        etage.numero = numero;
        return etage;
    }
    Salle newSalle(){ //Fonction créant une salle dans le format newSalle(Type de la salle, ouvert/fermer à gauche, à droite, en haut, en bas, pas visitée, 0 monstre)
        Salle salle = new Salle();
        return salle;
    }
    void initialiserSalle(Salle salle, TypeSalle type, boolean gauche, boolean droite, boolean haut, boolean bas, boolean visitee, int nbmonstre){
        salle.type = type;
        salle.gauche = gauche;
        salle.droite = droite;
        salle.haut = haut;
        salle.bas = bas;
        salle.visitee = visitee;
        salle.nbmonstre = nbmonstre;
    }
    void testInitialiserSalle(){
        String f = "../testExec/SalleSpawn.csv";
        Salle salle = newSalle();
        initialiserSalle(salle, recupType(f),recupGauche(f),recupDroite(f),recupHaut(f),recupBas(f),recupVisitee(f),recupNbmonstre(f));
        //initialiserSalle(salle, recupType(f),false,false,true,false,false,0);
        assertEquals(TypeSalle.SALLE_SPAWN, salle.type);
        assertFalse(salle.gauche);
        assertFalse(salle.droite);
        assertTrue(salle.haut);
        assertFalse(salle.bas);
        assertFalse(salle.visitee);
        assertEquals(0, salle.nbmonstre);

    }
    
    boolean stringToBoolean(String str){
        boolean resultat = false;
        if (equals(str,"true")){
            resultat = true;
        }else if (equals(str,"false")){
            resultat = false;
        }
        return resultat;
    }
    void testStringToBoolean(){
        String str = "true";
        assertTrue(stringToBoolean(str));
    }

    boolean recupBoolean(String FileName, int l){
        CSVFile fichier = loadCSV(FileName);
        String resultat = getCell(fichier,l,0);
        return stringToBoolean(resultat);

    }
    void testRecupBoolean2(){
        String fileName = "../testExec/SalleSpawn.csv";
        assertTrue(recupBoolean(fileName,3));
    }
    
    TypeSalle recupType(String FileName){
        CSVFile salle = loadCSV(FileName);
        String typeString = getCell(salle,0,0);
        if(equals(typeString, "COULOIR")){
           return TypeSalle.COULOIR;
        }else if(equals(typeString, "SALLE")){
           return TypeSalle.SALLE;
        }else if(equals(typeString, "SALLE_BOSS")){
           return TypeSalle.SALLE_BOSS;
        }else if(equals(typeString, "SALLE_SECRETE")){
           return TypeSalle.SALLE_SECRETE;
        }else if(equals(typeString, "PAS_SALLE")){
           return TypeSalle.PAS_SALLE;
        }else if(equals(typeString, "SALLE_SORTIE")){
           return TypeSalle.SALLE_SORTIE;
        }else if(equals(typeString, "SALLE_SPAWN")){
           return TypeSalle.SALLE_SPAWN;
        }else{
           return TypeSalle.SALLE_PASSERELLE;
        }
    }
 
   int recupNbmonstre(String FileName){
        CSVFile salle = loadCSV(FileName);
        int nbLigne = 0;
        String nbMonstre = getCell(salle,6,0);
        int resultat = 0;
        
        if (equals(nbMonstre,"0")){
            resultat = 0;
        }
        if (equals(nbMonstre,"1")){
            resultat = 1;
        }
        if (equals(nbMonstre,"2")){
            resultat = 2;
        }
        return resultat;
    }

    boolean recupVisitee(String FileName){ //Renvoit true si la salle est visitée false si non.
        return recupBoolean(FileName,5);
    }

    boolean recupGauche(String FileName){ //Renvoit true si la salle est ouverte à gauche false si non.
        return recupBoolean(FileName,1);
    }

    boolean recupDroite(String FileName){ //Renvoit true si la salle est ouverte à droite false si non
        return recupBoolean(FileName,2);
    }

    boolean recupHaut(String FileName){ //Renvoit true si la salle est ouverte en haut false si non
        return recupBoolean(FileName,3);
    }

    boolean recupBas(String FileName){ //Renvoit true si la salle est ouverte en bas false si non
        return recupBoolean(FileName,4);
    }

    void testRecupVisitéé(){
        String salle = "../testExec/SalleVide.csv";
        assertFalse(recupVisitee(salle));
    }
    void testRecupGauche(){
        String salle = "../testExec/SalleVide.csv";
        assertFalse(recupGauche(salle));
    }
    void testRecupHaut(){
        String salle = "../testExec/PasDeSalle.csv";
        assertFalse(recupHaut(salle));
    }

    void testRecupBas(){
        String salle = "../testExec/SalleSpawn.csv";
        Salle s = newSalle();
        s.bas = recupBas(salle);
        assertFalse(s.bas);
    }

    void testRecupNbmonstre(){
       String salle = "../testExec/SalleVide.csv";
       assertEquals(0, recupNbmonstre(salle));
    }
 
   void testRecupType(){
       String salle = "../testExec/SalleVide.csv";
       String salle2 = "../testExec/PasDeSalle.csv";
       assertEquals(TypeSalle.SALLE, recupType(salle));
       assertEquals(TypeSalle.PAS_SALLE, recupType(salle2));
    }


    void initialiserPlanEtage(Etage etage, String nomPlan){ //Fonction attribuant un plan(ensemble des salles) à un étage.
        CSVFile plan = loadCSV("../testExec/" + nomPlan);
        int nbLigneCSV = rowCount(plan);
        int nbColonneCSV = columnCount(plan);
        Salle s;
        String salle;
        for (int i = 0; i < nbLigneCSV; i=i+1){
            for (int j = 0; j < nbColonneCSV; j=j+1){
                salle = "../testExec/" + getCell(plan, i, j);
                s = newSalle();
                initialiserSalle(s,recupType(salle),recupGauche(salle),recupDroite(salle),recupHaut(salle),recupBas(salle),recupVisitee(salle), recupNbmonstre(salle));
                etage.plan[i][j] = s;
            }
        }
    }
    void testInitialiserPlanEtage(){ //Fonction qui test si l'etage correspond bien à un tableau à 2 dimensions de salles de type: PAS_SALLE.
        Etage etage = newEtage(1);
        initialiserPlanEtage(etage, "EtageVide..csv");
        boolean resultat = true;
        for (int i = 0; i<10; i=i+1){
            for (int j = 0; j<10; j=j+1){
                if (etage.plan[i][j].type != TypeSalle.PAS_SALLE){
                    resultat = false;
                }
            }
        }
        assertTrue(resultat);
    }
    void afficherPlanCSV(String nomPlan){ //Fonction affichant le contenu d'un fichier CSV représentant le plan d'un étage.
        CSVFile plan = loadCSV("../testExec/" + nomPlan);
        for (int i = 0; i<=10; i++){
            println();
            for (int j = 0; j<=10; j++){
                print(getCell(plan,0,0));
                print(",");
            }
        }
        println();
    }
    void afficherPlanVariable(Etage etage){ //Fonction affichant le plan avec le type de chaque salle d'une variable etage.
        for (int i = 0; i<10; i=i+1){
            println();
            for (int j = 0; j<10; j=j+1){
                print(etage.plan[i][j].type);
                print(",");
            }
        }
        println();
    }
    String typeSalleToString(TypeSalle typeSalle){
        String type = "";
        if(typeSalle == TypeSalle.COULOIR){
           type = "COULOIR";
       }else if(typeSalle == TypeSalle.SALLE_SECRETE){
           type = "SALLE_SECRETE";
       }else if(typeSalle == TypeSalle.PAS_SALLE){
           type = "PAS_SALLE";
       }else if(typeSalle == TypeSalle.SALLE){
           type = "SALLE";
       }else if(typeSalle == TypeSalle.SALLE_PASSERELLE){
           type = "SALLE_PASSERELLE";
       }else if(typeSalle == TypeSalle.SALLE_SORTIE){
           type = "SALLE_SORTIE";
       }else if(typeSalle == TypeSalle.SALLE_SPAWN){
           type = "SALLE_SPAWN";
       }else{
           type = "SALLE_BOSS";
       }
       return type;
    }
    String[][] tabSalleToTabString(Salle[][] plan){
        String[][] tab = new String[10][10];
        for (int i = 0; i<10; i=i+1){
            for (int j = 0; j<10; j=j+1){
                tab[i][j] = typeSalleToString(plan[i][j].type);
            }
        }
        return tab;
    }
    int calculResultatFormule(int facteur1, int facteur2, char operateur){
        int resultat = 0;
        if(operateur == '+'){
            resultat = (facteur1 + facteur2);
        }else if(operateur == '-'){
            resultat = (facteur1 - facteur2);
        }else if(operateur == '*'){
            resultat = (facteur1 * facteur2);
        }else if(operateur == '/'){
            resultat = (facteur1 / facteur2);
        }
        return resultat;
    }
    void testCalculResultatFormule(){
        assertEquals(20,calculResultatFormule(5, 4, '*'));
    }
    
    void creerTableAddition(){ //Fonction créant un fichier "addition.csv" contenant les tables d'addition de 1 à 100.
        String[][] tab = new String[10000][2];
        for(int i=1;i<=100;i++){
            for(int j=1;j<=100;j++){
                int resultat = i+j;
                tab[(i-1)*100+(j-1)][0] = (i + "+" + j);
                tab[(i-1)*100+(j-1)][1] = intToString(resultat);
            }
        }
        saveCSV(tab, "addition.csv");
    }
    void creerTableSoustraction(){
        int taille = 0;
        for (int i = 0; i<=100; i++){
            taille = taille + i;
        }
        String[][] tab = new String[taille][2];
        int compte = 0;
        for(int i=1;i<=100;i++){
            for(int j=1;j<=100;j++){
                if (i >= j){
                    int resultat = i-j;
                    tab[compte][0] = (i + "-" + j);  
                    tab[compte][1] = (intToString(resultat));
                    compte++;
                }
            }
        }
        saveCSV(tab, "soustraction.csv");
    }
    void creerTableMultiplication(){
        String[][] tab = new String[1000][2];
        int compte = 0;
        for(int i=1;i<=10;i++){
            for(int j=1;j<=100;j++){
                int resultat = i*j;
                tab[compte][0] = (i + "*" + j);
                tab[compte][1] = intToString(resultat);
                compte++;
            }
        }
        saveCSV(tab, "multiplication.csv");
    }
    void creerTableDivision(){
        int taille = 0;
        for(int i=1;i<=100;i++){
            for(int j=1;j<=100;j++){
                if(i%j == 0){
                    taille++;
                }
            }
        }
        String [][] tab = new String[taille][2];
        int compte = 0;
        for(int i=1;i<=100;i++){
            for(int j=1;j<=100;j++){
                if(i%j == 0){
                    int resultat = i/j;
                    tab[compte][0] = (i + "/" + j);
                    tab[compte][1] = intToString(resultat);
                    compte++;
                }
            }
        }
        saveCSV(tab, "division.csv");
    }
    boolean estPresentGolem(Salle salle){
        boolean present = false;
        if (salle.nbmonstre > 0){
            present = true;
        }
        return present;
    }
    void afficherDirectionPossible(Salle salle){
        boolean[] directions = new boolean[]{salle.gauche,salle.droite,salle.haut,salle.bas};
        String[] directionString = new String[]{"Gauche", "Droite", "Haut", "Bas"};
        int compte = 1;
        int indice = 0;
        while(indice < length(directions)){
            if(directions[indice] == true){
                print(compte + '-' + directionString[indice]);
                compte++;
            }
            indice++;
        }
    }
    String[] directionsPossibles(Salle salleActuelle){
        boolean[] directions = new boolean[]{salleActuelle.gauche,salleActuelle.droite,salleActuelle.haut,salleActuelle.bas};
        String[] directionString = new String[]{"gauche", "droite", "haut", "bas"};
        int compte = 0;
        int indice = 0;

        while(indice < length(directions)){
            if(directions[indice] == true){
                compte++;
            }
            indice++;
        }
        String[] dirPossibles = new String[compte];
        int cpt = 0;
        for(int i = 0; i<length(directions);i++){
            if(directions[i] == true){
                dirPossibles[cpt] = directionString[i];
                cpt++;
            }
        }
        return dirPossibles;
    }
    void testDirPossibles(){
        String[] dir = new String[]{"haut"}; 
        Salle salle = newSalle();
        initialiserSalle(salle,TypeSalle.SALLE_SPAWN,false,false,true,false,false,0);
        
        assertEquals(dir[0],directionsPossibles(salle)[0]);
    }
    void afficherChoixDeplacement(String[] dirPossibles){
        cursor(17,0);
        clearLine();
        afficherFichierTexte("../affichage/ChoixDeplacement.txt");
        cursor(17,0);
        for(int i = 1; i<=length(dirPossibles); i=i+1){
            cursor(18+i,87);
            println(i + "- " + dirPossibles[i-1] + " ");
        }
        cursor(24,0);
    }
    
    String choixDeplacement(String[] dirPossibles){
        String choix = "";
        do{
            choix = readString();
        }while(!estEntierDansIntervalle(choix, 1, length(dirPossibles)));
        
        return dirPossibles[StringToInt(choix)-1];
    }
    String inverseChoixDeplacement(String choix){
        String chaine = "";
        if (equals(choix,"gauche")){
            chaine = "droite";
        }else if (equals(choix,"droite")){
            chaine = "gauche";
        }else if (equals(choix,"haut")){
            chaine = "bas";
        }else if (equals(choix,"bas")){
            chaine = "haut";
        }
        return chaine;
    }
    void testInverseChoixDeplacement(){
        assertEquals("droite",inverseChoixDeplacement("gauche"));
        assertEquals("gauche",inverseChoixDeplacement("droite"));
        assertEquals("haut",inverseChoixDeplacement("bas"));
        assertEquals("bas",inverseChoixDeplacement("haut"));
    }
    Salle seDeplacer(int[] position, Etage etage, String choix){
        Salle salle = newSalle();
        if(equals(choix,"gauche")){
            position[1] = position[1] - 1; 
        }else if(equals(choix,"droite")){
            position[1] = position[1] + 1;
        }else if(equals(choix,"haut")){
            position[0] = position[0] - 1;
        }else if(equals(choix,"bas")){
            position[0] = position[0] + 1;
        }
        
        salle = etage.plan[position[0]][position[1]];
        return salle;
    }


    void afficherFichierTexte(String nomfichier){
        File fichier = newFile(nomfichier);
        while(ready(fichier)){
            println(readLine(fichier));
        }
    }
    boolean estEntier(String str){
        if (charAt(str,0) >= '0' && charAt(str,0) <= '9'){
            return true;
        }else{
            return false;
        }
    }
    void testEstEntier(){
        String str = "1";
        assertTrue(estEntier(str));
        str = "a";
        assertFalse(estEntier(str));
    }
    boolean estEntierDansIntervalle(String str, int min, int max){
        return (length(str) == 1 && estEntier(str) && (((int)charAt(str,0))/48) == 1 && StringToInt(str) >= min && StringToInt(str) <= max);
    }
    void testEstEntierDansIntervalle(){
        assertTrue(estEntierDansIntervalle("1", 1, 1));
        assertFalse(estEntierDansIntervalle("a", 1, 1));
    }
    void visiter(Salle salle){
        salle.visitee = true;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /* Fonction  d'affichage du plan de l'étage sous forme de minimap (NON IMPLÉMENTÉE)*/

    void afficherMap(Etage etage){
        int cadreLargeur = 52;

        ///////////////////////////////////////
        //Barre horizontal du cardre.
        print("#");
        for(int i=0; i <= cadreLargeur; i=i+1){
            print("—");
        }
        print("#");
        ///////////////////////////////////////

        for (int i=0; i<=10; i++){
            
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////

    String nomSalleParTypeSalle(Salle salle){
        String nom = "";
        if (salle.type == TypeSalle.SALLE_SPAWN){
            nom = "la Prison du Donjon";
        }else if (salle.type == TypeSalle.SALLE){
            nom = "une Salle";
        }else if (salle.type == TypeSalle.SALLE_BOSS){
            nom = "la Salle du BOSS";
        }
        return nom;

    }
    void afficherAction(Salle salleActuelle){
        clearScreen();
        cursor(1,1);
        afficherFichierTexte("../affichage/Action.txt");
        cursor(3,3);
        println("Vous vous trouvez dans " + nomSalleParTypeSalle(salleActuelle) + ".");
        cursor(4,0);
        println();
        if (salleActuelle.visitee == true){
            println("# La salle a été visitée.");
        }else{
            println("# La salle n'a pas été visitée.");
        }
        if (salleActuelle.nbmonstre > 0){
            cursor(6,0);
            println();
            if (salleActuelle.nbmonstre > 1){
                println("# ! ATTENTION ! Il y a " + salleActuelle.nbmonstre + " Golems dans la salle.");
            }else{
                println("# ! ATTENTION ! Il y a " + salleActuelle.nbmonstre + " Golem dans la salle.");
            }
            println();
        }
        cursor(12,0);
    }
    int choixAction(){
        String choix = "";
        do{
            choix = readString();
        }while(!estEntierDansIntervalle(choix,1,2));
        return stringToInt(choix);
    }
    
    void afficherDeplacmenentStats(){
        afficherFichierTexte("../affichage/MenuDeplacementStats.txt");
    }
    void afficherCombattreFuir(){
        afficherFichierTexte("../affichage/MenuCombattreFuir.txt");
    }
    void menu(Salle salleActuelle){
        if (salleActuelle.nbmonstre > 0){
            afficherCombattreFuir();
        }else{
            afficherDeplacmenentStats();
        }
        cursor(17,0);
    }
    boolean estSortie(Salle salleActuelle){
        return (salleActuelle.type == TypeSalle.SALLE_SORTIE);
    }
    void afficherStats(Joueur joueur){
        int lig = 11;
        int col = 3;
        String barre = "";
        for(int i=0; i<(joueur.pv); i+=1){
            barre = barre + "==";
        }
        String arme = "";
        int espace = 0;
        clearScreen();
        cursor(1,1);
        afficherFichierTexte("../affichage/Stats.txt");
        cursor(6,3);
        print(barre);
        cursor(6,25);
        print( joueur.pv + "/" + pvJoueur);
        cursor(11,3);
        println("+----------------------+");
        lig = lig + 1;
        cursor(lig, col);
        println("|                      |");
        lig = lig + 1;
        cursor(lig, col);
        for(int i=0; i<length(joueur.inventaireArme); i+=1){
            arme = joueur.inventaireArme[i].nom;
            espace = 16-length(arme);
            println("|  " + (i+1) + " : " + arme + espace(espace) + "|");
            lig = lig + 1;
            cursor(lig, col);
            println("|                      |");
            lig = lig + 1;
            cursor(lig, col);
        }
        
        println("+----------------------+");
        cursor(30,0);
        println("APPUYEZ SUR \"ENTREE\" POUR REVENIR EN ARRIÈRE.");
        cursor(31,0);

    }


//----------------------------------------------------------//

/*COMBAT*/

int recupDegat(Joueur joueur, int indicearme){
    return joueur.inventaireArme[indicearme].dmg;
}

int recupDegat(Golem golem){
    return golem.degat;
}


void testRecupDegatJoueur(){
    Arme a = newArme("epee", Rarete.commun, Type.melee, 4);
    Arme b = newArme("epee", Rarete.commun, Type.melee, 2);
    Arme c = newArme("epee", Rarete.commun, Type.melee, 6);
    Arme[] inventaire = new Arme[] {a,b,c};
    Joueur j = newJoueur(inventaire);
    assertEquals(recupDegat(j, 0), 4);
    assertEquals(recupDegat(j, 1), 2);
    assertEquals(recupDegat(j, 2), 6);
}

void testRecupDegatGolem(){
    Golem g1 = newGolem(10, 3);
    Golem g2 = newGolem(12, 5);
    assertEquals(recupDegat(g1), 3);
    assertEquals(recupDegat(g2), 5);
}

///////

int recupPv(Joueur joueur){
    return joueur.pv;
}

int recupPv(Golem golem){
    return golem.pv;
}

void testRecupPv(){
    Arme[] inventaire = new Arme[]{};
    Joueur j = newJoueur(inventaire);
    Golem g = newGolem(5, 2);
    assertEquals(recupPv(j),10);
    assertEquals(recupPv(g),5);
}

///////

void attaque(Joueur joueur,int indicearme, Golem golem){
    if(recupDegat(joueur,indicearme)>=recupPv(golem)){
        golem.pv=0;
    }else{
        golem.pv-=recupDegat(joueur,indicearme);
    }
}

void attaque(Golem golem, Joueur joueur){
    if(recupDegat(golem)>=recupPv(joueur)){
        joueur.pv=0;
    }else{
        joueur.pv-=recupDegat(golem);
    }
}


void testAttaque(){
    Arme a = newArme("epee", Rarete.commun, Type.melee, 4);
    Arme[] inventaire = new Arme[] {a};
    Joueur j = newJoueur(inventaire);
    Golem g1 = newGolem(5, 2);
    Golem g2 = newGolem(3, 2);
    Golem g3 = newGolem(4, 2);
    attaque(j, 0, g1);
    attaque(j, 0, g2);
    attaque(j, 0, g3);
    assertEquals(recupPv(g1),1);
    assertEquals(recupPv(g2),0);
    assertEquals(recupPv(g3),0);
    attaque(g1, j);
    assertEquals(recupPv(j),8);
}

///////

int choixArme(Joueur joueur, int lig, int col){
    cursor(lig, col);
    print("J'attaque avec l'arme numéro ");
    int rep = readInt();
    while(rep<1||rep>length(joueur.inventaireArme)){
        cursor(lig, col);
        println("Je n'ai pas cette arme !      ");
        delay(2000);
        cursor(lig, col);
        print("J'attaque avec l'arme numéro ");
        rep = readInt();
    }
    return rep-1;
}

/*
void testChoixArme(){
    Arme a = newArme("epee", Rarete.commun, Type.melee, 4);
    Arme b = newArme("epee", Rarete.commun, Type.melee, 2);
    Arme c = newArme("epee", Rarete.commun, Type.melee, 6);
    Arme[] inventaire = new Arme[] {a,b,c};
    Joueur j = newJoueur(inventaire);
    assertEquals(choixArme(j),1);
}
*/

///////

boolean calcul(int ligne, String file){
    CSVFile csv = loadCSV(file);
    print(getCell(csv,ligne,0) + " = ");
    int rep = readInt();
    if(equals(intToString(rep),getCell(csv,ligne,1))){
        return true;
    }else{
        return false;
    }
}

String fileAlea(){
    double prob = random();
    if(prob<0.25){
        return "../operation/addition.csv";
    }else if(prob<0.50){
        return "../operation/division.csv";
    }else if(prob<0.75){
        return "../operation/multiplication.csv";
    }else{
        return "../operation/soustraction.csv";
    }

}

int ligAlea(String file){
    CSVFile csv = loadCSV(file);
    int len = rowCount(csv);
    return (int) (random()*len);
}

boolean calculAlea(){
    String file = fileAlea();
    return calcul(ligAlea(file), file);
}

/*
void testCalcul(){
    assertTrue(calcul(9, "./operation/addition.csv"));
    assertFalse(calcul(4, "./operation/addition.csv"));
    assertTrue(calcul(150, "./operation/division.csv"));
    assertFalse(calcul(50, "./operation/division.csv"));
    assertTrue(calcul(425, "./operation/multiplication.csv"));
    assertFalse(calcul(374, "./operation/multiplication.csv"));
    assertTrue(calcul(78, "./operation/soustraction.csv"));
    assertFalse(calcul(361, "./operation/soustraction.csv"));
}
*/

///////

String espace(int nbespace){
    String espace = "";
    for(int i=0; i<nbespace; i+=1){
        espace = espace + " ";
    }
    return espace;
}

void afficheInventaire(Joueur joueur, int lig, int col){
    String arme;
    int espace;
    cursor(lig-1, col);
    print("Inventaire d'armes :");
    cursor(lig, col);
    println("+----------------------+");
    lig = lig + 1;
    cursor(lig, col);
    println("|                      |");
    lig = lig + 1;
    cursor(lig, col);
    for(int i=0; i<length(joueur.inventaireArme); i+=1){
        arme = joueur.inventaireArme[i].nom;
        espace = 16-length(arme);
        println("|  " + (i+1) + " : " + arme + espace(espace) + "|");
        lig = lig + 1;
        cursor(lig, col);
        println("|                      |");
        lig = lig + 1;
        cursor(lig, col);
    }
    println("+----------------------+");
}

///////

void ligneAffichage(int pos){
    String ligne = "";
    for(int i=0; i<40; i+=1){
        ligne = ligne + "-";
    }
    ligne = ligne + "+";
    for(int i=0; i<121; i+=1){
        ligne = ligne + "-";
    }
    ligne = ligne + "+";
    for(int i=0; i<40; i+=1){
        ligne = ligne + "-";
    }
    cursor(pos,0);
    print(ligne);
}

void affichageCombat(Joueur joueur, Golem golem){
    clearScreen();
    ligneAffichage(40);
    for(int i=0; i<10; i+=1){
        cursor((41+i),41);
        print("|");
        cursor((41+i),163);
        print("|");
    }
    ligneAffichage(51);
    affichagePv(joueur,45, 5);
    affichagePv(golem,45, 170);
}

///////

void affichagePv(Joueur joueur, int lig, int col){
    String barre = "";
    cursor(lig-2, col);
    print("Joueur :");
    cursor(lig, col);
    print("+--------------------+");
    cursor(lig+1, col);
    print("|");
    cursor(lig+2, col);
    print("+--------------------+");
    for(int i=0; i<(joueur.pv); i+=1){
        barre = barre + "==";
    }
    cursor(lig+1, col+1);
    print(barre);
    cursor(lig+1, col+21);
    print("|  " + joueur.pv + "/" + pvJoueur);
}

void affichagePv(Golem golem, int lig, int col){
    String barre = "";
    cursor(lig-2, col);
    print("Golem :");
    cursor(lig, col);
    print("+--------------------+");
    cursor(lig+1, col);
    print("|");
    cursor(lig+2, col);
    print("+--------------------+");
    for(int i=0; i<(golem.pv); i+=1){
        barre = barre + "====";
    }
    cursor(lig+1, col+1);
    print(barre);
    cursor(lig+1, col+21);
    print("|  " + golem.pv + "/" + pvGolem);
}

///////

void combat(Joueur joueur, Salle salle){
    Golem golem;
    int arme;
    while(salle.nbmonstre>0 && recupPv(joueur)>0){
        golem = newGolem(pvGolem, degGolem);
        affichageCombat(joueur, golem);
        affichageGolemSalle(salle);
        cursor(45, 95);
        print("Un golem arrive !");
        delay(2000);
        while(recupPv(golem)>0 && recupPv(joueur)>0){
            affichageCombat(joueur, golem);
            affichageGolemSalle(salle);
            afficheInventaire(joueur, 26, 10);
            arme = choixArme(joueur, 45, 90);
            affichageCombat(joueur, golem);
            affichageGolemSalle(salle);
            cursor(45, 95);
            if(calculAlea()){
                attaque(joueur, arme, golem);
                affichageCombat(joueur, golem);
                affichageGolemSalle(salle);
                cursor(45,85);
                print("Vous avez infligé " + recupDegat(joueur, arme) + " dégat(s) au golem !");
            }else{
                attaque(golem, joueur);
                affichageCombat(joueur, golem);
                affichageGolemSalle(salle);
                cursor(45,85);
                print("Le golem vous a infligé " + recupDegat(golem) + " dégat(s) !");
            }
            delay(2000);
            if(recupPv(golem)<=0){
                salle.nbmonstre = salle.nbmonstre-1;
                affichageCombat(joueur, golem);
                cursor(45,90);
                println("Le golem a été vaincu !");
                delay(2000);
            }
        }
    }
    if(recupPv(joueur)<=0){
        cursor(45,70);
        print("                    Vous avez été vaincu !                    ");
    }
    if(salle.nbmonstre<=0){
        cursor(45,80);
        print("Vous avez vaincu tout les golems de cette salle !");
    }
    delay(5000);
    cursor(60,1);
}


//------------------------------------------------------//

void affichageGolem(String nomfichier, int lig, int col){
    File fichier = newFile(nomfichier);
    int ligcont = lig;
    while(ready(fichier)){
        cursor(ligcont, col);
        print(readLine(fichier));
        ligcont++;
    }
}

void affichageGolemSalle(Salle salle){
    if(salle.type==TypeSalle.SALLE_BOSS){
        affichageGolem("../affichage/boss.txt", 4, 74);
    }else{
        affichageGolem("../affichage/golem.txt", 20, 75);
    }
}
void afficherIntroTuto(){
    clearScreen();
    afficherFichierTexte("../affichage/IntroTuto.txt");
    readString();
}

    void algorithm(){
        String choix = "";

        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Armes disponibles en jeu.
        Arme a = newArme("epee", Rarete.commun, Type.melee, 4);
        Arme b = newArme("glaive", Rarete.commun, Type.melee, 2);
        Arme c = newArme("sabre", Rarete.commun, Type.melee, 6);
        Arme d = newArme("katana", Rarete.commun, Type.melee, 6);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Création du joueur.
        Arme[] inventaire = new Arme[] {a,b,c,d};
        Joueur j = newJoueur(inventaire);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Création des Golems du jeu.
        Golem golem = newGolem(pvGolem, degGolem);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        while(!equals(choix,"0")){
            clearScreen();
            cursor(1,1);
            afficherFichierTexte("../affichage/Accueil.txt");
            
            do{
                choix = readString();
                
            }while(!estEntierDansIntervalle(choix, 0, 2));
        
            ////////////////////////////////////////////////////////////////////////////////////////////////////////
            // Lance le tutoriel de combat du jeu.

            if (equals(choix,"1")){
                
                Etage etage = newEtage(1);
                initialiserPlanEtage(etage, "EtageTutoCombat.csv");

                int[] positionActuelle = new int[]{2,0};
                Salle salleActuelle = etage.plan[positionActuelle[0]][positionActuelle[1]];
                Salle sallePrecedente = newSalle();
                String[] dirPossibles = directionsPossibles(salleActuelle);
                String choixDeplacement = "";
                
                clearScreen();
                cursor(1,1);
                afficherIntroTuto();
                readString();
                clearScreen();

                while(!estSortie(salleActuelle) && j.pv > 0){
                    dirPossibles =directionsPossibles(salleActuelle);
                    afficherAction(salleActuelle);
                    menu(salleActuelle);
                    // Si un ou des golems sont présent, le joueur choisi de combattre ou de fuir.
                    if (estPresentGolem(salleActuelle)){
                        // Le joueur choisi de combattre.
                        if (choixAction() == 1){
                            combat(j, salleActuelle);
                            visiter(salleActuelle);
                        }
                        // Le joueur choisi de fuir.
                        else {
                            salleActuelle = seDeplacer(positionActuelle, etage, inverseChoixDeplacement(choixDeplacement));
                        }
                    }
                    // Sinon le joueur choisi de se déplacer dans une autre salle ou d'observer ses statistique (points de vie et armes).
                    else if (!estPresentGolem(salleActuelle)){
                        // Le joueur choisi de se déplacer.
                        if (choixAction() == 1){
                            afficherChoixDeplacement(dirPossibles);
                            choixDeplacement = choixDeplacement(dirPossibles);
                            visiter(salleActuelle);
                            sallePrecedente = salleActuelle;
                            salleActuelle = seDeplacer(positionActuelle, etage, choixDeplacement);
                        }
                        // Le joueur choisi de voir ses stats.
                        else {
                            afficherStats(j);
                            readString();
                        }
                    }
                }
                if (estSortie(salleActuelle)){
                    clearScreen();
                    cursor(1,1);
                    afficherFichierTexte("../affichage/FinTutoCombat.txt");
                    readString();
                    choix = "";
                }else{
                    clearScreen();
                    cursor(1,1);
                    afficherFichierTexte("../affichage/Perdu.txt");
                    readString();
                    choix = "";
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////


            if (equals(choix,"2")){
                
                Etage etage = newEtage(1);
                initialiserPlanEtage(etage, "EtagePartie.csv");

                int[] positionActuelle = new int[]{8,4};
                Salle salleActuelle = etage.plan[positionActuelle[0]][positionActuelle[1]];
                Salle sallePrecedente = newSalle();
                String[] dirPossibles = directionsPossibles(salleActuelle);
                String choixDeplacement = "";
                
                while(!estSortie(salleActuelle) && j.pv > 0){
                    dirPossibles =directionsPossibles(salleActuelle);
                    afficherAction(salleActuelle);
                    menu(salleActuelle);
                    // Si un ou des golems sont présent, le joueur choisi de combattre ou de fuir.
                    if (estPresentGolem(salleActuelle)){
                        // Le joueur choisi de combattre.
                        if (choixAction() == 1){
                            combat(j, salleActuelle);
                            visiter(salleActuelle);
                        }
                        // Le joueur choisi de fuir.
                        else {
                            salleActuelle = seDeplacer(positionActuelle, etage, inverseChoixDeplacement(choixDeplacement));
                        }
                    }
                    // Sinon le joueur choisi de se déplacer dans une autre salle ou d'observer ses statistique (points de vie et armes).
                    else if (!estPresentGolem(salleActuelle)){
                        // Le joueur choisi de se déplacer.
                        if (choixAction() == 1){
                            afficherChoixDeplacement(dirPossibles);
                            choixDeplacement = choixDeplacement(dirPossibles);
                            visiter(salleActuelle);
                            sallePrecedente = salleActuelle;
                            salleActuelle = seDeplacer(positionActuelle, etage, choixDeplacement);
                        }
                        // Le joueur choisi de voir ses stats.
                        else {
                            afficherStats(j);
                            readString();
                        }
                    }
                }
                if (estSortie(salleActuelle)){
                    clearScreen();
                    cursor(1,1);
                    afficherFichierTexte("../affichage/Fin.txt");
                    readString();
                    choix = "";
                }else{
                    clearScreen();
                    cursor(1,1);
                    afficherFichierTexte("../affichage/Perdu.txt");
                    readString();
                    choix = "";
                }
                
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////
        }
    }
}
    
