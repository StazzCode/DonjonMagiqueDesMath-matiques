class Arme {
   String nom;
   Rarete rarete;
   Type type;
   int dmg;
}