DonjonMagiqueDesMathématiques
===========

Développé par Kellian Mirey Gautier Damblin
Contacts : <kellian.mirey.etu@univ-lille.fr> , <gautier.damblin.etu@univ-lille.fr>

# Présentation de <DonjonMagiqueDesMathématiques>

<Description de votre jeu>
Le DonjonMagique des Mathématiques est un RPG où l'on incarne un chevalier prisonnier d'un donjon infesté de Golems qui peuvent être vaincus en résolvant des opérations mathématiques pour les attaquer. Le but est donc de sortir du donjon sans se faire batte par les Golem pour devenir le chevalier le plus intelligent de la Contrée.


# Utilisation de <DonjonMagiqueDesMathématiques>

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh DonjonMagique
```
Permet le lancement du jeu
